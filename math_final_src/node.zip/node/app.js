//导入 express 模块, npm install express -S
//导入 cors模块, npm install cors -S
const express = require("express")
const cors = require("cors");
var fs = require('fs')


let app = express();
//处理跨域问题
app.use(cors());

//设置api接口,请求该接口的时候返回 hello world
app.get("/api",function(req,res){
    //在命令行中查看传递过来的参数
    fs.readFile('./username.txt', 'utf-8', (err, data) => {
        // console.log(data);
        json = data
        let arr = json.split(';')
        console.log(arr)
        let pushArr = []
        let flag = false
        arr.forEach(el => {
            if(el == "") return
            let obj = {}
            if(el.split(" ")[0] === req.query.username) {
                let f = 0
                console.log(Number(req.query.fraction), Number(el.split(" ")[1]));
                if(Number(req.query.fraction) > Number(el.split(" ")[1])) {
                    f = req.query.fraction
                }else {
                    f = el.split(" ")[1]
                }
                flag = true
                obj = {
                    name: req.query.username,
                    fraction: f
                }
            }else {
                obj = {
                    name: el.split(" ")[0],
                    fraction: el.split(" ")[1]
                }
            }
            pushArr.push(obj)
        })

        if(!flag) {
            pushArr.push({
                name: req.query.username,
                fraction: req.query.fraction
            })
        }
        
        let text = ""
        pushArr.forEach(el => {
            text += `${el.name} ${el.fraction};`
        })

        fs.writeFile('./username.txt', text,'utf-8', (err, data) => {
            
        })

        res.end(JSON.stringify({data: pushArr}))
    })
    
   
})



app.post("/list", function(req, res) {
    let json = ''
    fs.readFile('./username.txt', 'utf-8', (err, data) => {
        // console.log(data);
        json = data
        let arr = json.split(';')
        let pushArr = []
        arr.forEach(el => {
            let obj = {
                name: el.split(" ")[0],
                fraction: el.split(" ")[1]
            }
            pushArr.push(obj)
        })
        res.end(JSON.stringify({data: pushArr}))
    })
    
})

app.listen(3000);
